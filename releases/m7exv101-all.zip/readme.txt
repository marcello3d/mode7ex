Mode 7 ex v1.01 - Full Extension Bundle
---------------------------------------
by marcello (marcello@cellosoft.com)

Visit http://www.cellosoft.com/
---------------------------------------

Bundle Contents:

	readme.txt	- this file
	m7ex-v1.01.exe	- Mode 7 ex extension installer: installs JUST the extension!

	docs/		- Mode 7 ex documentation (open docs/index.html)
	examples/	- Multimedia Fusion 1.5 example files as listed in docs/examples.html
	
---------------------------------------

Enjoy!

-Marcello

---------------------------------------